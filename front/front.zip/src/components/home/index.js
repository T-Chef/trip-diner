export { default as Header } from "./Header";
export { default as Footer } from "./Footer";
export { default as Hero } from "./Hero";
export { default as Section1 } from "./Section1";
export { default as Section2 } from "./Section2";
export { default as Section3 } from "./Section3";
export { default as SideMenu } from "./SideMenu";